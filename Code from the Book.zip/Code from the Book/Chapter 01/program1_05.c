// Program 1.5 Another Simple C Program - Displaying Great Quotations
#include <stdio.h>

int main(void)
{
  printf("\"It is a wise father that knows his own child.\"\nShakespeare\n");
  return 0;
}

