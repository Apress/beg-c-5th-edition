// Program 1.6 A Simple C Program - Important
#include <stdio.h>

int main(void)
{
  printf("Be careful!!\n\a");
  return 0;
}

