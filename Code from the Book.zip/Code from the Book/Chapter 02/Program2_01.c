// Program 2.1 What is a Variable?
#include <stdio.h>

int main(void)
{
  printf("My salary is $10000");
  return 0;
}

